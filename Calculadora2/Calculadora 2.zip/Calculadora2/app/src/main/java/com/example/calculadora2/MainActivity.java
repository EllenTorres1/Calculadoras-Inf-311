package com.example.calculadora2;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends Activity {

    private EditText editText;
    private String atual = "";
    private String anterior = "";
    private String operador = "";
    private boolean isResultDisplayed = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editText = findViewById(R.id.editText);
    }

    public void onNumberClick(View view) {
        if (isResultDisplayed) {
            atual = "";
            isResultDisplayed = false;
        }

        Button button = (Button) view;
        atual += button.getText().toString();
        editText.setText(atual);
    }


    public void onOperatorClick(View view) {
        if (isResultDisplayed) {
            anterior = atual;
            atual = "";
            isResultDisplayed = false;
        } else if (!atual.isEmpty()) {
            anterior = atual;
            atual = "";
        }

        Button button = (Button) view;
        operador = button.getText().toString();
    }

    public void onEqualClick(View view) {
        if (!anterior.isEmpty() && !atual.isEmpty()) {
            try {
                double operand1 = Double.parseDouble(anterior);
                double operand2 = Double.parseDouble(atual);
                double result = 0;

                switch (operador) {
                    case "+":
                        result = operand1 + operand2;
                        break;
                    case "-":
                        result = operand1 - operand2;
                        break;
                    case "*":
                        result = operand1 * operand2;
                        break;
                    case "/":
                        if (operand2 == 0) {
                            editText.setText("ERROR");
                            return;
                        }
                        result = operand1 / operand2;
                        break;
                }

                atual = String.valueOf(result);
                editText.setText(atual);
                isResultDisplayed = true;
            } catch (NumberFormatException e) {
                editText.setText("ERROR");
            }
        }
    }


    public void onClearClick(View view) {
        atual = "";
        anterior = "";
        operador = "";
        editText.setText("");
    }


    public void onBackspaceClick(View view) {
        if (atual.length() > 0) {
            atual = atual.substring(0, atual.length() - 1);
            editText.setText(atual);
        }
    }


    public void onDotClick(View view) {
        if (isResultDisplayed) {
            atual = "";
            isResultDisplayed = false;
        }

        if (!atual.contains(".")) {
            atual += ".";
            editText.setText(atual);
        }
    }
}
